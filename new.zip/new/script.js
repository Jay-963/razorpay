$(document).ready(function () {
    // Make an AJAX request to get orderId and signature
    $.ajax({
        url: 'generate_order.php', // Update with the correct path to your PHP script
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            var orderId = data.orderId;
            var signature = data.signature;

            var options = {
                key: 'rzp_test_SW6PzpWF1E4ULk', // Replace with your actual Razorpay key
                amount: 50000, // amount in paisa (e.g., 50000 for ₹500)
                currency: 'INR',
                name: 'Decore Figure',
                description: 'Purchase Description',
                image: 'https://sbbjitsolutions.in/decore/assets/img/dlogo.png',
                order_id: orderId,
                prefill: {
                    name: 'John Doe',
                    email: 'john@example.com',
                    contact: '9999999999'
                },
                handler: function(response) {
                    // Handle the success callback
                    console.log('Payment ID:', response.razorpay_payment_id);
                    console.log('Order ID:', response.razorpay_order_id);
                    console.log('Signature:', response.razorpay_signature);
                    var orderId = response.razorpay_order_id;
                    var paymentId = response.razorpay_payment_id;
                    var signature = response.razorpay_signature;
            
                      // Make an AJAX request to your PHP server to verify the payment
                    $.ajax({
                        url: 'verify-payment.php', // Update with your PHP file name
                        type: 'POST',
                        dataType: 'json',
                        data: {
                          orderId: orderId,
                          paymentId: paymentId,
                          signature: signature
                        },
                        success: function (data) {
                          console.log('Payment verification response:', data);
                          alert('Payment Successful!');
                        },
                        error: function (error) {
                          console.error('Error verifying payment:', error);
                          alert('Payment verification failed!');
                        }
                    });
                    
                }
            };

            var rzp = new Razorpay(options);
            rzp.open();
        },
        error: function (xhr, status, error) {
            console.error('Error generating order:', error);
        }
    });
});
