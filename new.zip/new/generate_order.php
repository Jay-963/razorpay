<?php
// Include Razorpay PHP library
require_once('vendor/razorpay/razorpay/Razorpay.php');

// Replace 'your_api_key' and 'your_api_secret' with your actual Razorpay API key and secret
$razorpayApiKey = 'rzp_test_SW6PzpWF1E4ULk';
$razorpayApiSecret = 'sDfgp7E0MoT1WHm0QZBuT3Iv';

use Razorpay\Api\Api;

$api = new Api($razorpayApiKey, $razorpayApiSecret);

// Define the order amount (in paisa)
$orderAmount = 50000; // Replace with the actual order amount

$orderData = [
    'receipt' => 'order_receipt_id', // Replace with a unique order receipt ID
    'amount' => $orderAmount,
    'currency' => 'INR',
    'payment_capture' => 1 // Auto capture payment
];

$order = $api->order->create($orderData);

// Generate signature
$signature = hash_hmac('sha256', $order->id . '|' . $order->receipt, $razorpayApiSecret);

// Return the order ID and signature as JSON
echo json_encode([
    'orderId' => $order->id,
    'signature' => $signature
]);
?>
