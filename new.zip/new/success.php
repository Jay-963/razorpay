<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Success</title>
</head>
<body>

  <h1>Payment Successful!</h1>

  <script>
    // Extract payment details from the URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const paymentId = urlParams.get('payment_id');
    const orderId = urlParams.get('order_id');
    const signature = urlParams.get('signature');

    // Display payment details (customize as needed)
    document.body.innerHTML += `
      <p>Payment ID: ${paymentId}</p>
      <p>Order ID: ${orderId}</p>
      <p>Signature: ${signature}</p>
    `;
  </script>

</body>
</html>
