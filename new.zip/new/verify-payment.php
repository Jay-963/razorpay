<?php
// Replace 'rzp_test_your_test_key' and 'rzp_test_your_test_secret' with your Razorpay test key and secret
$razorpayKey = 'rzp_test_SW6PzpWF1E4ULk';
$razorpaySecret = 'sDfgp7E0MoT1WHm0QZBuT3Iv';

// Get data from the AJAX request
$orderId = $_POST['orderId'];
$paymentId = $_POST['paymentId'];
$signature = $_POST['signature'];

// Generate a signature on the server
$generatedSignature = hash_hmac('sha256', $orderId . '|' . $paymentId, $razorpaySecret);

// Check if the generated signature matches the received signature
if ($generatedSignature === $signature) {
    // Signature is valid, mark the payment as successful in your system
    // You should also check and compare the payment amount, etc.

    // For simplicity, let's assume a successful verification
    echo json_encode(['status' => 'success', 'message' => 'Payment verification successful']);
} else {
    // Signature is not valid, mark the payment as unsuccessful in your system
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid signature']);
}
?>
